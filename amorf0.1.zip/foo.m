function v2=foo(v1)
v2=v1;