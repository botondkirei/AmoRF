% amoRF
% Version 1.0 (R2010a) 3-Mar-2011
%
%  Common Classes
%
%   BaseClass           - Common properties and methods.
%   SignalClass         - Signal properties and methods .
%   AttributeClass    - Tamplate class for nonidealities.
%   BlockClass      - Tamplate class for RF components.
%   ReceiverClass       - Tamplate class for RF components.
%
%  Attribute Classes //not complete yet!!!
%
%   NoiseClass      - Common properties and methods.
%   SignalClass     - Signal properties and methods .
%   GainClass       - Tamplate class for nonidealities.
%   BClass  - Tamplate class for RF components.
%   ReceiverClass   - Tamplate class for RF components.
%
%  Related products:
%
%  See also RF, simRF



