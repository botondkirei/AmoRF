function output=db(input)
    output=20*log10(input);
end