%[1] Citirea unui pachet OFDM din obiectul FullOFDMFrameSignal.m 
    load FullOFDMFrameSignal.mat;
    Signal = FullOFDMFrameSignal;
    Signal.Samples = Signal.Samples(1:end/34); % objectul FullOFDMFrameSignal 
    Signal.Fc=0;
    Signal.Samples=10^(30/20)*Signal.Samples;
    %contine 34 de pachete OFDM
%[2] Incarcarea receptorului cu conversie directa
    REC=DCR;
    REC.Architecture.MIX.Architecture.CFO.Offset=REC.Architecture.MIX.Architecture.CFO.Offset +23e6;
    %pentru ca CFOClass a fost pregatit pentru simulare lowpass equivalent
    %simulation, pentru demodulare corecta in prezenta simulare este
    %necesar adunarea frecventei purtatoare a semnalului dorit.
%% [3] Receptia pachetului OFDM
    sout = REC.run(Signal);
%% [4] Afisari semnale
Signal.freq;
sout.freq;

l=length(sout.Samples);
faxes=((1:l)/l*sout.Fs)-(sout.Fs/2)+sout.Fc;
%H=freqz(b,a,faxes,sout.Fs);
            
figure(1); 
axes('FontSize',16); 
Signal.dB; grid on; 
xlabel('Frequency (Hz)', 'fontsize', 16);
ylabel('Amplitude (dB)','fontsize',16);
figure(2); 
axes('FontSize',16); 
REC.Architecture.LNA.Signal.dB; grid on;
xlabel('Frequency (Hz)', 'fontsize', 16);
ylabel('Amplitude (dB)','fontsize',16);
figure(3); 
axes('FontSize',16); 
REC.Architecture.MIX.Signal.dB; grid on;
xlabel('Frequency (Hz)', 'fontsize', 16);
ylabel('Amplitude (dB)','fontsize',16);
figure(4); 
axes('FontSize',16); 
REC.Architecture.LPF.Signal.dB; grid on; hold on; %plot(faxes,db(abs(H)),'r');
xlabel('Frequency (Hz)', 'fontsize', 16);
ylabel('Amplitude (dB)','fontsize',16);
figure(5); 
axes('FontSize',16); 
REC.Architecture.AGC.Signal.dB; grid on;
xlabel('Frequency (Hz)', 'fontsize', 16);
ylabel('Amplitude (dB)','fontsize',16);