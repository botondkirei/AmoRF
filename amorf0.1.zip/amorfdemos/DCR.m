function REC=DCR(~)
%[1] build the RF blocks with nonidealities
%   [1.1] The Band Pass Filter (BPF)
%       [1.1.1] Thermal noise in the BPF
        tnBPF = NoiseClass('Noise');
        tnBPF.write('NF',0);
        tnBPF.R=50;
        tnBPF.B=8e6;
        % [1.1.2] Frequency selectivity of the BPF
        Flt.b=1;
        Flt.a=1;
        fsBPF=FreqSelClass('FreqSelect',Flt);
        % [1.1.3] Adding NonlinearityClass to implement the gain of DBF
        nlBPF=GainClass('Gain');
        nlBPF.A1 = 10^(-3/20);
        nlBPF.A3 = 10^(-15/20);
        % [1.1.3] Instanciating a wrapper class for the BPF and adding the
        % nonidealities to it
        BPF = BlockClass('BPF');
        BPF.add(nlBPF);
        BPF.add(tnBPF);
        BPF.add(fsBPF);
        
%   [1.2] The Low Noise Amplifier (LNA)
%       [1.2.1] Thermal noise in the LNA
        tnLNA = NoiseClass('Noise');
        tnLNA.write('NF',1.5); %noise figure 1.5 dB
        tnLNA.R=50;
        tnLNA.B=8e6;
        % [1.2.2] Nonlinearity of the LNA
        nlLNA=GainClass('Gain');
        nlLNA.A1 = 10^(15/20); %15 dB
        nlLNA.A3 = 10^(150/20); % add third order component
        % [1.2.3] Instanciating a wrapper class for the LNA and adding the
        % nonidealities to it
        LNA = BlockClass('LNA');
        LNA.add(tnLNA);
        LNA.add(nlLNA);
        
    %[1.3] Mixer (MIX)
        %[1.3.1] Termal noise in the mixer
        tnMIX = NoiseClass('Noise');
        tnMIX.write('NF', 12);
        tnMIX.R=50;
        tnMIX.B=8e6;
        % [1.3.2] Nonlinearity in MIX
        nlMIX=GainClass('Gain');
        nlMIX.A1 = 10^(20/20); %20 dB
        nlMIX.A3 = 0.001; % no third order component
        % [1.3.3] I/Q imbalance in Mix
        iqMIX = IQImbalClass('IQImbalance');
        iqMIX.g=1.1;
        iqMIX.phi=10;
        % [1.3.4] CFO in MIX
        cfoMIX=FreqConvClass('CFO');
        cfoMIX.Offset=1e6;
        % [1.3.5] Instanciating a wrapper class for the MIX and adding the
        % nonidealities to it
        MIX = BlockClass('MIX');
        MIX.add(tnMIX);
        MIX.add(nlMIX);
        MIX.add(cfoMIX);
        MIX.add(iqMIX);
        
    % [1.4] Low Pass Filter (LPF)
        % [1.4.1] Termal noise in LPF
        tnLPF = NoiseClass('Noise');
        tnLPF.write('NF',30);
        tnLPF.R=50;
        tnLPF.B=8e6;
        % [1.4.2] Nonlinearity of the LPF
        nlLPF=GainClass('Gain');
        nlLPF.A1 = 1; %1 dB
        nlLPF.A3 = 0.001; % no third order component
        % [1.4.3] Frequency selectivity

        %fsLPF.Flt=fir1(10,0.4e7/1.82857e7*2);
        %[b,a]=cheby2(6, 50, 0.15);
        load lowpassfilter.mat;
        Flt.a=a;
        Flt.b=b;
        fsLPF=FreqSelClass('FreqSelect',Flt);
        % [1.4.4]  Instanciating a aggregate object for  LPF and adding the
        % nonidealities to it
        LPF = BlockClass('LPF');
        LPF.add(nlLPF);
        LPF.add(fsLPF);
        LPF.add(tnLPF);

%   [1.5] The Automatic Gain Control (AGC)Block
%       [1.5.1] Thermal noise in the AGC
        tnAGC = NoiseClass('Noise');
        tnAGC.write('NF', 30);
        tnAGC.R=50;
        tnAGC.B=8e6;
        % [1.2.2] Nonlinearity of the LNA
        nlAGC=GainClass('Gain');
        nlAGC.A1 = 10^(60/20); %15 dB
        nlAGC.A3 = 0.000001; % no third order component
        % [1.2.3] Instanciating a wrapper class for the LNA and adding the
        % nonidealities to it
        AGC = BlockClass('AGC');
        AGC.add(tnAGC);
        AGC.add(nlAGC);

        % [2] Build the receiver
    REC = TunerClass('DCR');
    REC.add(BPF);
    REC.add(LNA);
    REC.add(MIX);
    REC.add(LPF);
    REC.add(AGC);
    % Display structure
    proba(REC.getstructure);
% [3] Generate an input signal and runit trough the receiver
   % s=SignalClass(randn(10000,1)+1i*randn(10000,1),1);
   % s=effect(REC,s);
