% amoRF
% Version 1.0 (R2010a) 3-Mar-2011
%
%  Common Classes
%
%   BaseClass           - Common properties and methods.
%   SignalClass         - Signal properties and methods .
%   AttributeClass    - Template class for nonidealities.
%   BlockClass      - Template class for RF components.
%   ReceiverClass       - Template class for RF components.